# Predictive Analytics + Customer Segmentation

A beginner-friendly Python internship project with:
1. A Streamlit web app that forecasts a numeric metric from historical data.
2. A standalone K-Means script that groups customers by annual income and spending score.

## Concepts you will learn
- **Data cleaning:** convert dates, coerce numeric values, remove invalid rows and duplicate dates.
- **Regression:** learn a relationship between time index and a numeric target.
- **Evaluation:** MAE and RMSE measure typical prediction error; R² gives a model-fit score when it can be calculated.
- **Visualization:** compare historical values, holdout predictions, and future forecasts.
- **Customer segmentation:** scale income/spending features and use K-Means to discover groups with similar behavior.

## Project structure
```text
predictive_analytics_project/
├── app.py
├── customer_segmentation.py
├── requirements.txt
├── README.md
├── data/
│   ├── historical_sales.csv
│   └── customers.csv
└── outputs/                 # created by segmentation script
```

## Run the web app
1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the app:
   ```bash
   streamlit run app.py
   ```
6. Open the local URL shown in the terminal. The app starts with the included sample dataset; you can upload your own CSV.

### Historical CSV format
Include one date/time column and at least one numeric target column, for example:
```csv
Date,Sales
2025-01-01,120
2025-01-02,125
```
Choose the date and target in the app.

## Run customer segmentation
```bash
python customer_segmentation.py
```
The script reads `data/customers.csv`, creates four K-Means segments, and saves:
- `outputs/customers_with_segments.csv`
- `outputs/customer_segments.png`

## How to explain the project in an interview
"I cleaned historical data, used time-index linear regression as a baseline forecast, evaluated it on the most recent 20% of observations, and plotted the results. I also built a separate K-Means customer segmentation script using standardized income and spending features."

## Important limitations
- The forecast is an educational baseline. It does not automatically model seasonality, holidays, or external factors.
- The sample data is synthetic and intended for practice, not business decisions.
- K-Means segment numbers are arbitrary labels; Segment 0 is not inherently better than Segment 1.
