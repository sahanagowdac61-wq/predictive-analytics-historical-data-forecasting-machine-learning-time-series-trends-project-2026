import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

st.set_page_config(page_title="Predictive Analytics Dashboard", page_icon="📈", layout="wide")
st.title("📈 Predictive Analytics Using Historical Data")
st.write("Upload historical data, select a date and numeric target column, and forecast future values.")

@st.cache_data
def load_sample():
    return pd.read_csv("data/historical_sales.csv")

uploaded = st.file_uploader("Upload a CSV file (optional)", type=["csv"])
try:
    df = pd.read_csv(uploaded) if uploaded else load_sample()
except Exception as exc:
    st.error(f"Could not read the file: {exc}")
    st.stop()

st.subheader("1. Preview and prepare data")
st.caption("The dataset should contain a date/time column and a numeric column to forecast.")
st.dataframe(df.head(10), use_container_width=True)

date_col = st.selectbox("Choose date/time column", df.columns, index=0)
numeric_cols = [c for c in df.columns if c != date_col and pd.api.types.is_numeric_dtype(df[c])]
if not numeric_cols:
    st.error("No numeric target column found. Please upload a CSV with at least one numeric column.")
    st.stop()
target_col = st.selectbox("Choose numeric target to forecast", numeric_cols)
horizon = st.slider("How many future periods to forecast?", min_value=1, max_value=30, value=7)

work = df[[date_col, target_col]].copy()
work[date_col] = pd.to_datetime(work[date_col], errors="coerce")
work[target_col] = pd.to_numeric(work[target_col], errors="coerce")
work = work.dropna().sort_values(date_col).reset_index(drop=True)
work = work.drop_duplicates(subset=[date_col], keep="last")
if len(work) < 5:
    st.error("Please provide at least 5 valid dated observations.")
    st.stop()

# A simple time-index regression model; useful as a beginner baseline.
work["time_index"] = np.arange(len(work))
X = work[["time_index"]]
y = work[target_col]
test_size = max(1, int(round(len(work) * 0.2)))
if len(work) - test_size < 2:
    st.error("Not enough observations to train and evaluate the model.")
    st.stop()

X_train, X_test = X.iloc[:-test_size], X.iloc[-test_size:]
y_train, y_test = y.iloc[:-test_size], y.iloc[-test_size:]
model = LinearRegression()
model.fit(X_train, y_train)
test_predictions = model.predict(X_test)

mae = mean_absolute_error(y_test, test_predictions)
rmse = float(np.sqrt(mean_squared_error(y_test, test_predictions)))
r2 = r2_score(y_test, test_predictions) if len(y_test) > 1 else float("nan")

c1, c2, c3 = st.columns(3)
c1.metric("Mean Absolute Error", f"{mae:.2f}")
c2.metric("Root Mean Squared Error", f"{rmse:.2f}")
c3.metric("R² score", f"{r2:.3f}" if np.isfinite(r2) else "N/A")

st.subheader("2. Historical values and model fit")
fig, ax = plt.subplots()
ax.plot(work[date_col], y, marker="o", label="Historical")
ax.plot(work[date_col].iloc[-test_size:], test_predictions, marker="x", linestyle="--", label="Test predictions")
ax.set_xlabel("Date")
ax.set_ylabel(target_col)
ax.set_title(f"{target_col}: historical data and holdout predictions")
ax.legend()
ax.tick_params(axis="x", rotation=35)
fig.tight_layout()
st.pyplot(fig)

# Estimate typical interval between dates and extend the time index.
date_diffs = work[date_col].diff().dropna()
step = date_diffs.median() if not date_diffs.empty else pd.Timedelta(days=1)
if pd.isna(step) or step <= pd.Timedelta(0):
    step = pd.Timedelta(days=1)
future_dates = [work[date_col].iloc[-1] + step * i for i in range(1, horizon + 1)]
future_indices = np.arange(len(work), len(work) + horizon).reshape(-1, 1)
future_values = model.predict(future_indices)

forecast = pd.DataFrame({date_col: future_dates, f"predicted_{target_col}": future_values})
st.subheader("3. Forecast")
st.dataframe(forecast, use_container_width=True)
fig2, ax2 = plt.subplots()
ax2.plot(work[date_col], y, marker="o", label="Historical")
ax2.plot(future_dates, future_values, marker="o", linestyle="--", label="Forecast")
ax2.set_xlabel("Date")
ax2.set_ylabel(target_col)
ax2.set_title(f"Future forecast for {target_col}")
ax2.legend()
ax2.tick_params(axis="x", rotation=35)
fig2.tight_layout()
st.pyplot(fig2)

st.download_button("Download forecast CSV", forecast.to_csv(index=False).encode("utf-8"),
                   file_name="forecast.csv", mime="text/csv")
st.info("Learning note: this is a simple linear-regression baseline, not a guarantee of future outcomes. For seasonal data, try dedicated time-series models and compare them on a time-based holdout.")
