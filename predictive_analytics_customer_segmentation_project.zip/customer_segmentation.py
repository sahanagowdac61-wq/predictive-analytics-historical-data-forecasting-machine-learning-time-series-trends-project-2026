"""Beginner-friendly customer segmentation with K-Means.

Run: python customer_segmentation.py
Input: data/customers.csv
Outputs: outputs/customers_with_segments.csv and outputs/customer_segments.png
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "customers.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_PATH)
features = ["AnnualIncome", "SpendingScore"]
X = df[features].copy()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = KMeans(n_clusters=4, random_state=42, n_init=10)
df["Segment"] = model.fit_predict(X_scaled)

print("Customer count by segment:")
print(df["Segment"].value_counts().sort_index())
print("\nSegment averages:")
print(df.groupby("Segment")[features].mean().round(2))

out_csv = OUTPUT_DIR / "customers_with_segments.csv"
df.to_csv(out_csv, index=False)

plt.figure(figsize=(8, 5))
for segment in sorted(df["Segment"].unique()):
    subset = df[df["Segment"] == segment]
    plt.scatter(subset["AnnualIncome"], subset["SpendingScore"], label=f"Segment {segment}")
plt.xlabel("Annual income")
plt.ylabel("Spending score")
plt.title("Customer Segments (K-Means)")
plt.legend()
plt.tight_layout()
plot_path = OUTPUT_DIR / "customer_segments.png"
plt.savefig(plot_path, dpi=150)
print(f"\nSaved segmented data to: {out_csv}")
print(f"Saved chart to: {plot_path}")
